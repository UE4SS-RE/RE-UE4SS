-- /Script/Engine.GameplayStatics:CreatePlayer

IsInitialized = false
GameplayStatics = nil

function GetPlayerController()
    local PlayerControllers = FindAllOf("PlayerController")
    local PlayerController = nil
    for Index,Controller in pairs(PlayerControllers) do
        if Controller.Pawn:IsValid() and Controller.Pawn:IsPlayerControlled() then
            PlayerController = Controller
        else
            print("Not valid or not player controlled\n")
        end
    end
    if PlayerController and PlayerController:IsValid() then
        return PlayerController
    else
        error("No PlayerController found\n")
    end
end

function Init()
    GameplayStatics = StaticFindObject("/Script/Engine.Default__GameplayStatics")

    if not GameplayStatics:IsValid() then error("GameplayStatics not valid\n") end

    IsInitialized = true
end

function CreatePlayer()
    if not IsInitialized then return end

    print(string.format("GameplayStatics: %s\n", GameplayStatics:GetFullName()))
    local NewController = GameplayStatics:CreatePlayer(GetPlayerController(), -1, true)
    if NewController:IsValid() then
        print("Player created\n")
        print(string.format("NewController: %s\n", NewController:GetFullName()))
    else
        print("Player could not be created\n")
    end
end

RegisterKeyBind(Key.Y, {ModifierKey.CONTROL}, function()
    Init()
    -- Execute code inside the game thread.
    -- Will execute as soon as the game has time to execute.
    ExecuteInGameThread(function()
        print("Creating player\n")
        CreatePlayer()
    end)
end)
